﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ed_s_Hardware
{
    public partial class Dashboard : MetroFramework.Forms.MetroForm
    { 
        public Dashboard()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            userControl11.Hide(); //Users
            userControl21.Hide(); //Suppliers
            userControl31.Hide(); //Stock
            userControl41.Show(); //Home
            userControl51.Hide(); //About

           
            
        }



        private void label8_Click(object sender, EventArgs e)
        {

        }


        //***********************************HOME BUTTON*************************************
        private void btnHome_Click(object sender, EventArgs e)
        {
            userControl11.Hide(); //Users
            userControl21.Hide(); //Suppliers
            userControl31.Hide(); //Stock
            userControl41.Show(); //Home
            userControl51.Hide(); //About
        }
        //***********************************SUPPLIERS BUTTON*********************************
        private void btnSuppliers_Click(object sender, EventArgs e)
        {
            userControl11.Hide(); //Users
            userControl21.Show(); //Suppliers
            userControl31.Hide(); //Stock
            userControl41.Hide(); //Home
            userControl51.Hide(); //About
        }
        //***********************************STOCK BUTTON*************************************
        private void btnStocks_Click(object sender, EventArgs e)
        {
            userControl11.Hide(); //Users
            userControl21.Hide(); //Suppliers
            userControl31.Show(); //Stock
            userControl41.Hide(); //Home
            userControl51.Hide(); //About
        }
        //***********************************USER BUTTON*************************************
        private void BtnUsers_Click(object sender, EventArgs e)
        {
            userControl11.Show(); //Users
            userControl21.Hide(); //Suppliers
            userControl31.Hide(); //Stock
            userControl41.Hide(); //Home
            userControl51.Hide(); //About
        }
        //***********************************ABOUT BUTTON************************************
        private void btnAbout_Click(object sender, EventArgs e)
        {
            userControl11.Hide(); //Users
            userControl21.Hide(); //Suppliers
            userControl31.Hide(); //Stock
            userControl41.Hide(); //Home
            userControl51.Show(); //About
        }
        //***********************************EXITING THE APPLICATION*************************************
        private void Dashboard_FormClosing(object sender, FormClosingEventArgs e)
        {

            DialogResult dialog = MessageBox.Show("You are about to Exit the application, Do you want to Exit?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.Yes)
            {

                Application.Exit();
            }
            else if (dialog == DialogResult.No)
            {
                e.Cancel = true;

            }


      
        }
    }
}
