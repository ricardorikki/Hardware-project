﻿
namespace Ed_s_Hardware
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.btnAbout = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.StudentPhoto = new System.Windows.Forms.PictureBox();
            this.btnStocks = new System.Windows.Forms.Button();
            this.btnSuppliers = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnHome = new System.Windows.Forms.Button();
            this.BtnUsers = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.userControl11 = new Ed_s_Hardware.UserControl1();
            this.userControl21 = new Ed_s_Hardware.UserControl2();
            this.userControl31 = new Ed_s_Hardware.UserControl3();
            this.userControl41 = new Ed_s_Hardware.UserControl4();
            this.userControl51 = new Ed_s_Hardware.UserControl5();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StudentPhoto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkBlue;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.btnAbout);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.StudentPhoto);
            this.panel2.Controls.Add(this.btnStocks);
            this.panel2.Controls.Add(this.btnSuppliers);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.btnHome);
            this.panel2.Controls.Add(this.BtnUsers);
            this.panel2.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(185, 616);
            this.panel2.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(26, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 32);
            this.label3.TabIndex = 61;
            this.label3.Text = "Welcome";
            // 
            // btnAbout
            // 
            this.btnAbout.BackColor = System.Drawing.Color.DarkBlue;
            this.btnAbout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAbout.FlatAppearance.BorderSize = 0;
            this.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAbout.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbout.ForeColor = System.Drawing.Color.White;
            this.btnAbout.Image = global::Ed_s_Hardware.Properties.Resources.PinClipart_com_autopsy_clipart_3334785;
            this.btnAbout.Location = new System.Drawing.Point(0, 572);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(200, 44);
            this.btnAbout.TabIndex = 60;
            this.btnAbout.Text = "   About";
            this.btnAbout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAbout.UseVisualStyleBackColor = false;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(28, 246);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 21);
            this.label2.TabIndex = 59;
            this.label2.Text = "Ricardo Knight";
            // 
            // StudentPhoto
            // 
            this.StudentPhoto.Image = global::Ed_s_Hardware.Properties.Resources.PinClipart_com_user_clipart_1653686;
            this.StudentPhoto.Location = new System.Drawing.Point(13, 118);
            this.StudentPhoto.Name = "StudentPhoto";
            this.StudentPhoto.Size = new System.Drawing.Size(151, 125);
            this.StudentPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.StudentPhoto.TabIndex = 58;
            this.StudentPhoto.TabStop = false;
            // 
            // btnStocks
            // 
            this.btnStocks.BackColor = System.Drawing.Color.DarkBlue;
            this.btnStocks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnStocks.FlatAppearance.BorderSize = 0;
            this.btnStocks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStocks.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStocks.ForeColor = System.Drawing.Color.White;
            this.btnStocks.Image = global::Ed_s_Hardware.Properties.Resources.ClipartKey_203145;
            this.btnStocks.Location = new System.Drawing.Point(-11, 399);
            this.btnStocks.Name = "btnStocks";
            this.btnStocks.Size = new System.Drawing.Size(211, 44);
            this.btnStocks.TabIndex = 8;
            this.btnStocks.Text = "   Stocks";
            this.btnStocks.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnStocks.UseVisualStyleBackColor = false;
            this.btnStocks.Click += new System.EventHandler(this.btnStocks_Click);
            // 
            // btnSuppliers
            // 
            this.btnSuppliers.BackColor = System.Drawing.Color.DarkBlue;
            this.btnSuppliers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSuppliers.FlatAppearance.BorderSize = 0;
            this.btnSuppliers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuppliers.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuppliers.ForeColor = System.Drawing.Color.White;
            this.btnSuppliers.Image = ((System.Drawing.Image)(resources.GetObject("btnSuppliers.Image")));
            this.btnSuppliers.Location = new System.Drawing.Point(0, 349);
            this.btnSuppliers.Name = "btnSuppliers";
            this.btnSuppliers.Size = new System.Drawing.Size(185, 44);
            this.btnSuppliers.TabIndex = 7;
            this.btnSuppliers.Text = "    Suppliers";
            this.btnSuppliers.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSuppliers.UseVisualStyleBackColor = false;
            this.btnSuppliers.Click += new System.EventHandler(this.btnSuppliers_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(40, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 19);
            this.label1.TabIndex = 6;
            this.label1.Text = "Dashboard";
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.DarkBlue;
            this.btnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.White;
            this.btnHome.Image = ((System.Drawing.Image)(resources.GetObject("btnHome.Image")));
            this.btnHome.Location = new System.Drawing.Point(-11, 299);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(196, 44);
            this.btnHome.TabIndex = 6;
            this.btnHome.Text = "   Home";
            this.btnHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // BtnUsers
            // 
            this.BtnUsers.BackColor = System.Drawing.Color.DarkBlue;
            this.BtnUsers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnUsers.FlatAppearance.BorderSize = 0;
            this.BtnUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnUsers.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnUsers.ForeColor = System.Drawing.Color.White;
            this.BtnUsers.Image = ((System.Drawing.Image)(resources.GetObject("BtnUsers.Image")));
            this.BtnUsers.Location = new System.Drawing.Point(-11, 449);
            this.BtnUsers.Name = "BtnUsers";
            this.BtnUsers.Size = new System.Drawing.Size(211, 44);
            this.BtnUsers.TabIndex = 5;
            this.BtnUsers.Text = "   Users";
            this.BtnUsers.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnUsers.UseVisualStyleBackColor = false;
            this.BtnUsers.Click += new System.EventHandler(this.BtnUsers_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Ed_s_Hardware.Properties.Resources._792_l1;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(188, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(141, 69);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // userControl11
            // 
            this.userControl11.BackColor = System.Drawing.Color.White;
            this.userControl11.Location = new System.Drawing.Point(188, 52);
            this.userControl11.Name = "userControl11";
            this.userControl11.Size = new System.Drawing.Size(911, 561);
            this.userControl11.TabIndex = 3;
            // 
            // userControl21
            // 
            this.userControl21.BackColor = System.Drawing.Color.White;
            this.userControl21.Location = new System.Drawing.Point(188, 52);
            this.userControl21.Name = "userControl21";
            this.userControl21.Size = new System.Drawing.Size(911, 561);
            this.userControl21.TabIndex = 3;
            // 
            // userControl31
            // 
            this.userControl31.BackColor = System.Drawing.Color.White;
            this.userControl31.Location = new System.Drawing.Point(188, 52);
            this.userControl31.Name = "userControl31";
            this.userControl31.Size = new System.Drawing.Size(911, 561);
            this.userControl31.TabIndex = 3;
            // 
            // userControl41
            // 
            this.userControl41.BackColor = System.Drawing.Color.White;
            this.userControl41.Location = new System.Drawing.Point(188, 52);
            this.userControl41.Name = "userControl41";
            this.userControl41.Size = new System.Drawing.Size(911, 561);
            this.userControl41.TabIndex = 3;
            // 
            // userControl51
            // 
            this.userControl51.BackColor = System.Drawing.Color.White;
            this.userControl51.Location = new System.Drawing.Point(188, 52);
            this.userControl51.Name = "userControl51";
            this.userControl51.Size = new System.Drawing.Size(911, 561);
            this.userControl51.TabIndex = 3;
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1090, 616);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.userControl11);
            this.Controls.Add(this.userControl21);
            this.Controls.Add(this.userControl31);
            this.Controls.Add(this.userControl41);
            this.Controls.Add(this.userControl51);
            this.Controls.Add(this.panel2);
            this.MaximizeBox = false;
            this.Name = "Dashboard";
            this.Resizable = false;
            this.ShadowType = MetroFramework.Forms.MetroForm.MetroFormShadowType.DropShadow;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Dashboard_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StudentPhoto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button BtnUsers;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnStocks;
        private System.Windows.Forms.Button btnSuppliers;
        private System.Windows.Forms.Button btnAbout;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox StudentPhoto;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private UserControl1 userControl11;
        private UserControl2 userControl21;
        private UserControl3 userControl31;
        private UserControl4 userControl41;
        private UserControl5 userControl51;
    }
}